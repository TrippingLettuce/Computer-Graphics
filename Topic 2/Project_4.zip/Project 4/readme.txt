in terminal, cd to your working directory and run makefile

$ make run



image pixel location:
https://pixlr.com/e/#editor = it will give you x and y coordinate.


image color generator
https://imagecolorpicker.com/ = it will give you the rgba color for pixel spot.