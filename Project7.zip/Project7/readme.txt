------------------------------------------------------------------------------------
Project 7:
Caleb Klinger, Kyungchan Im (Chris)
Grand Canyon University
------------------------------------------------------------------------------------
First make sure to install required packages and update

sudo apt update
sudo apt install freeglut3-dev libglu1-mesa-dev mesa-common-dev


RUN PART 1

1) cd "/path/to/directory/"
2) $g++ CheckeredTriangles.cpp -o Triangle -lglut -lGL -lGLU
3) ./Triangle 

RUN PART 2

1) cd "/path/to/directory/"
2) $g++ ColorCubeFlyby.cpp -o Colorcube -lglut -lGL -lGLU
3) ./Colorcube 


------------------------------------------------------------------------------------
Scene execution file folder: It contains the built OpenGL graphics, so if everything fails due to unexpected error, run this file.


------------------------------------------------------------------------------------
Github Link:
https://github.com/TrippingLettuce/Computer-Graphics/tree/main/Project7Files